package com.bignerdranch.android.photogallery.model

class Photo {
}