package com.bignerdranch.android.photogallery.api.response

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class PhotoResponse {
}